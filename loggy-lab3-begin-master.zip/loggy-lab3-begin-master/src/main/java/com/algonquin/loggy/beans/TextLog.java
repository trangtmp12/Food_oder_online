package com.algonquin.loggy.beans;

public class TextLog extends Log {

}
