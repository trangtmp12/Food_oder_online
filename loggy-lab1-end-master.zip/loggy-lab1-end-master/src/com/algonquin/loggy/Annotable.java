package com.algonquin.loggy;

public interface Annotable {
	public void attachFile(String name, String type, String content, Long size) throws Exception;

	public boolean isValidContentType(String contentType);

}
