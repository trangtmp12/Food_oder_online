package com.algonquin.loggy.dao;

import com.algonquin.loggy.services.ApplicationService;

public class ApplicationDao implements ApplicationService {

    public ApplicationDao() {

    }

}
