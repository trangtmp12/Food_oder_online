package com.algonquin.loggy.inmemory;

import com.algonquin.loggy.services.ApplicationService;

public class ApplicationInMemory implements ApplicationService {

    public ApplicationInMemory() {

    }
}
