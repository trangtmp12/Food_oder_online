package com.algonquin.loggy.services;

public interface ApplicationService {

}
